from django.shortcuts import render
from Myapp.models import categorydb

# Create your views here.
def newindex(request):
    data = categorydb.objects.all()
    return render(request,'newwebindex.html',{'data':data})

def aboutpage(request):
    return render(request,'About.html')
def contactpage(request):
    return render(request,'Contact.html')