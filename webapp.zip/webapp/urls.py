from django.urls import path
from webapp import views

urlpatterns=[
    path('newindex/',views.newindex,name='newindex'),
    path('aboutpage/',views.aboutpage,name='aboutpage'),
    path('contactpage/',views.contactpage,name='contactpage')
]